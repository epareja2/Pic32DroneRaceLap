/*******************************************************************************
 Touch adc 10bit Driver Local Interface File
 
  Company:
    Microchip Technology Inc.

  File Name:
    drv_ads7843_local.h

  Summary:
    Touch adc 10bit Local Driver interface header file.

  Description:
    This header file describes the macros, data structure and prototypes of the 
    touch adc 10bit local driver interface.
 ******************************************************************************/

// DOM-IGNORE-BEGIN
// DOM-IGNORE-END

#ifndef _DRV_TOUCH_ADS7843_LOCAL_H
#define _DRV_TOUCH_ADS7843_LOCAL_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include  <cp0defs.h>
#include "driver/touch/drv_touch.h"
#include "driver/touch/ads7843/drv_ads7843.h"
#include "osal/osal.h"
#include "system/int/sys_int.h"
#include "system/debug/sys_debug.h"

// *****************************************************************************
/* 

  Summary:
    

  Description:
    

  Remarks:
    use this scale factor to avoid working in floating point numbers

*/
#define ADS7843_FREQ  2000000           /* ADS7843 DCLK frequency. */
#define HALFTIME      SYS_CLK_FREQ / ADS7843_FREQ / 4


#define SCALE_FACTOR (1<<DRV_TOUCH_ADS7843_CALIBRATION_SCALE_FACTOR)

#if (DISP_ORIENTATION == 90)
    #define ADC_MaxXGet() (DISP_VER_RESOLUTION - 1)
#elif (DISP_ORIENTATION == 270)
    #define ADC_MaxXGet() (DISP_VER_RESOLUTION - 1)
#elif (DISP_ORIENTATION == 0)
    #define ADC_MaxXGet() (DISP_HOR_RESOLUTION - 1)
#elif (DISP_ORIENTATION == 180)
    #define ADC_MaxXGet() (DISP_HOR_RESOLUTION - 1)
#endif
#if (DISP_ORIENTATION == 90)
    #define ADC_MaxYGet() (DISP_HOR_RESOLUTION - 1)
#elif (DISP_ORIENTATION == 270)
    #define ADC_MaxYGet() (DISP_HOR_RESOLUTION - 1)
#elif (DISP_ORIENTATION == 0)
    #define ADC_MaxYGet() (DISP_VER_RESOLUTION - 1)
#elif (DISP_ORIENTATION == 180)
    #define ADC_MaxYGet() (DISP_VER_RESOLUTION - 1)
#endif


// ***** ADS7843 READ CODES WITH DIFERENTIAL READING CONFIG ******
#define ADS7843_READ_X          0b11010000 // IRQ Enable    / 12 bits  
#define ADS7843_READ_Y          0b10010000 // IRQ Enable    / 12 bits    


/*****************************************************************************
  Summary:
  Description:
  Remarks:
*****************************************************************************/
#define CAL_X_INSET    (((ADC_MaxXGet()+1)*(DRV_TOUCH_ADS7843_CALIBRATION_INSET>>1))/100)

/*****************************************************************************
  Summary:
  Description:
  Remarks:
******************************************************************************/
#define CAL_Y_INSET    (((ADC_MaxYGet()+1)*(DRV_TOUCH_ADS7843_CALIBRATION_INSET>>1))/100)

/*****************************************************************************
  Summary:
  Description:
  Remarks:
******************************************************************************/
#define DRV_ADS7843_SAMPLE_POINTS   4


/*****************************************************************************
  Summary:
  Description:
  Remarks:
******************************************************************************/
typedef struct {
    /* */
    SYS_STATUS       status;

    /* */
    SYS_MODULE_INDEX touchId;

    /* */
    bool              isExclusive;

    /* */
    uint8_t           numClients;

    /* */
    uint16_t          orientation;          

    /* */
    uint16_t          horizontalResolution; 

    /* */
    uint16_t          verticalResolution;
    
    // 
    bool              MustReadTouch;
    
    /* Touch status */
    DRV_TOUCH_POSITION_STATUS       touchStatus;
    
    DRV_TOUCH_PEN_STATE  penState;

} DRV_ADS7843_OBJECT;

/*****************************************************************************
  Summary:
  Description:
  Remarks:
******************************************************************************/
typedef struct {
    /* Driver Object associated with the client */
    DRV_ADS7843_OBJECT * driverObject;

    /* The intent with which the client was opened */
    DRV_IO_INTENT         intent;

} DRV_ADS7843_CLIENT_OBJECT;

//******************************************************************************
// Local functions
//******************************************************************************
void  _DRV_TOUCH_ADS7843_HardwareInit       (void *initValues);
void  _DRV_TOUCH_ADS7843_CalculateCalPoints (void);
void _delayms(unsigned long int msDelay );
uint16_t ADS7843ReadData(uint8_t Cmd);

#endif

/*******************************************************************************
 End of File
*/
