#include "gfx/hal/inc/gfx_processor_interface.h"


GFX_Result GFX_InitializeProcessorList()
{

    return GFX_SUCCESS;
}