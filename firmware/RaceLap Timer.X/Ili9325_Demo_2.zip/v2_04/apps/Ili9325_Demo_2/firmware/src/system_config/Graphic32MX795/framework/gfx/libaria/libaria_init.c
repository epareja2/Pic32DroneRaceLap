/*******************************************************************************
  MPLAB Harmony Graphics Composer Generated Implementation File

  File Name:
    libaria_init.c

  Summary:
    Build-time generated implementation from the MPLAB Harmony
    Graphics Composer.

  Description:
    Build-time generated implementation from the MPLAB Harmony
    Graphics Composer.

    Created with MPLAB Harmony Version 2.04
*******************************************************************************/
// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*******************************************************************************/
// DOM-IGNORE-END

#include "gfx/libaria/libaria_init.h"

laScheme defaultScheme;
laScheme BackGrowndGradient;
laScheme BigTextSchema;
laScheme Primitives;
laScheme ButtonsNormal;
laScheme WindowCaption;
laGradientWidget* GradientWidget1;
laLabelWidget* LabelWidget2;
laWidget* PanelWidget4;
laButtonWidget* MainOKBtn;
laButtonWidget* MainCancelBtn;
laLabelWidget* LabelWidget;
laButtonWidget* ButtonWidget1;
laButtonWidget* EEPromBtn;
laButtonWidget* ButtonWidget2;
laLabelWidget* LabelWidget;
laLabelWidget* LabelWidget4;
laLabelWidget* LabelWidget5;
laGradientWidget* GradientWidget;
laLabelWidget* TouchCalibrationWndCaption;
laWidget* PanelWidget6;
laButtonWidget* ButtonWidget7;
laButtonWidget* ButtonWidget8;
laCircleWidget* CirclePoint;
laImageWidget* ImageWidget6;
laLabelWidget* TouchPointLbl;
laLabelWidget* LabelWidget1;
laLabelWidget* LabelWidget3;
laGradientWidget* GradientWidget2;
laLabelWidget* LabelWidget6;
laWidget* PanelWidget7;
laButtonWidget* ButtonWidget9;
laButtonWidget* ButtonWidget10;
laDrawSurfaceWidget* DrawSurfaceWidget13;
laCircleWidget* CircleWidget14;
laLineWidget* LineWidget16;
laLineWidget* LineWidget15;
laTextFieldWidget* TextFieldWidget11;


static void ScreenCreate_MainWnd(laScreen* screen);
static void ScreenCreate_TouchCalibrationWnd(laScreen* screen);
static void ScreenCreate_DemoWnd(laScreen* screen);


int32_t libaria_initialize(void)
{
    laScreen* screen;

    laScheme_Initialize(&defaultScheme, GFX_COLOR_MODE_RGB_565);
    defaultScheme.base = 0xC67A;
    defaultScheme.highlight = 0xC67A;
    defaultScheme.highlightLight = 0xFFFF;
    defaultScheme.shadow = 0x8410;
    defaultScheme.shadowDark = 0x4208;
    defaultScheme.foreground = 0x0;
    defaultScheme.foregroundInactive = 0xD71C;
    defaultScheme.foregroundDisabled = 0x8410;
    defaultScheme.background = 0xFFFF;
    defaultScheme.backgroundInactive = 0xD71C;
    defaultScheme.backgroundDisabled = 0xC67A;
    defaultScheme.text = 0x0;
    defaultScheme.textHighlight = 0x1F;
    defaultScheme.textHighlightText = 0xFFFF;
    defaultScheme.textInactive = 0xD71C;
    defaultScheme.textDisabled = 0x8C92;

    laScheme_Initialize(&BackGrowndGradient, GFX_COLOR_MODE_RGB_565);
    BackGrowndGradient.base = 0xC67A;
    BackGrowndGradient.highlight = 0xC67A;
    BackGrowndGradient.highlightLight = 0xFFFF;
    BackGrowndGradient.shadow = 0x8410;
    BackGrowndGradient.shadowDark = 0x4208;
    BackGrowndGradient.foreground = 0x818;
    BackGrowndGradient.foregroundInactive = 0x9CFD;
    BackGrowndGradient.foregroundDisabled = 0x8410;
    BackGrowndGradient.background = 0xFFFF;
    BackGrowndGradient.backgroundInactive = 0xD71C;
    BackGrowndGradient.backgroundDisabled = 0xC67A;
    BackGrowndGradient.text = 0x0;
    BackGrowndGradient.textHighlight = 0x1F;
    BackGrowndGradient.textHighlightText = 0xFFFF;
    BackGrowndGradient.textInactive = 0xD71C;
    BackGrowndGradient.textDisabled = 0x8C92;

    laScheme_Initialize(&BigTextSchema, GFX_COLOR_MODE_RGB_565);
    BigTextSchema.base = 0xC67A;
    BigTextSchema.highlight = 0xC67A;
    BigTextSchema.highlightLight = 0xFFFF;
    BigTextSchema.shadow = 0x8410;
    BigTextSchema.shadowDark = 0x4208;
    BigTextSchema.foreground = 0x0;
    BigTextSchema.foregroundInactive = 0xD71C;
    BigTextSchema.foregroundDisabled = 0x8410;
    BigTextSchema.background = 0xFFFF;
    BigTextSchema.backgroundInactive = 0xD71C;
    BigTextSchema.backgroundDisabled = 0xC67A;
    BigTextSchema.text = 0xFFFF;
    BigTextSchema.textHighlight = 0x1F;
    BigTextSchema.textHighlightText = 0xFFFF;
    BigTextSchema.textInactive = 0xD71C;
    BigTextSchema.textDisabled = 0x8C92;

    laScheme_Initialize(&Primitives, GFX_COLOR_MODE_RGB_565);
    Primitives.base = 0xC67A;
    Primitives.highlight = 0xC67A;
    Primitives.highlightLight = 0xFFFF;
    Primitives.shadow = 0x8410;
    Primitives.shadowDark = 0x4208;
    Primitives.foreground = 0xFFFF;
    Primitives.foregroundInactive = 0xD71C;
    Primitives.foregroundDisabled = 0x8410;
    Primitives.background = 0xFFFF;
    Primitives.backgroundInactive = 0xD71C;
    Primitives.backgroundDisabled = 0xC67A;
    Primitives.text = 0x0;
    Primitives.textHighlight = 0x1F;
    Primitives.textHighlightText = 0xFFFF;
    Primitives.textInactive = 0xD71C;
    Primitives.textDisabled = 0x8C92;

    laScheme_Initialize(&ButtonsNormal, GFX_COLOR_MODE_RGB_565);
    ButtonsNormal.base = 0xC67A;
    ButtonsNormal.highlight = 0xC67A;
    ButtonsNormal.highlightLight = 0xFFFF;
    ButtonsNormal.shadow = 0x8410;
    ButtonsNormal.shadowDark = 0x4208;
    ButtonsNormal.foreground = 0x0;
    ButtonsNormal.foregroundInactive = 0xD71C;
    ButtonsNormal.foregroundDisabled = 0x8410;
    ButtonsNormal.background = 0x87F0;
    ButtonsNormal.backgroundInactive = 0xD71C;
    ButtonsNormal.backgroundDisabled = 0xC67A;
    ButtonsNormal.text = 0x0;
    ButtonsNormal.textHighlight = 0x1F;
    ButtonsNormal.textHighlightText = 0xFFFF;
    ButtonsNormal.textInactive = 0xD71C;
    ButtonsNormal.textDisabled = 0x8C92;

    laScheme_Initialize(&WindowCaption, GFX_COLOR_MODE_RGB_565);
    WindowCaption.base = 0x37E9;
    WindowCaption.highlight = 0xC67A;
    WindowCaption.highlightLight = 0xFFFF;
    WindowCaption.shadow = 0x8410;
    WindowCaption.shadowDark = 0x4208;
    WindowCaption.foreground = 0x0;
    WindowCaption.foregroundInactive = 0xD71C;
    WindowCaption.foregroundDisabled = 0x8410;
    WindowCaption.background = 0xFFE0;
    WindowCaption.backgroundInactive = 0xE4E7;
    WindowCaption.backgroundDisabled = 0x2690;
    WindowCaption.text = 0xFFFF;
    WindowCaption.textHighlight = 0xFFFF;
    WindowCaption.textHighlightText = 0xFFFF;
    WindowCaption.textInactive = 0xD71C;
    WindowCaption.textDisabled = 0x8C92;

    screen = laScreen_New(LA_FALSE, LA_FALSE, &ScreenCreate_MainWnd);
    laContext_AddScreen(screen);

    screen = laScreen_New(LA_FALSE, LA_FALSE, &ScreenCreate_TouchCalibrationWnd);
    laContext_AddScreen(screen);

    screen = laScreen_New(LA_FALSE, LA_FALSE, &ScreenCreate_DemoWnd);
    laContext_AddScreen(screen);

    laContext_SetPreemptionLevel(LA_PREEMPTION_LEVEL_1);
    GFX_Set(GFXF_DRAW_PIPELINE_MODE, GFX_PIPELINE_GCUGPU);
    laContext_SetStringTable(&stringTable);
    laContext_SetActiveScreen(0);

	return 0;
}

static void ScreenCreate_MainWnd(laScreen* screen)
{
    laLayer* layer0;

    layer0 = laLayer_New();
    laWidget_SetPosition((laWidget*)layer0, 0, 0);
    laWidget_SetSize((laWidget*)layer0, 240, 320);
    laWidget_SetBackgroundType((laWidget*)layer0, LA_WIDGET_BACKGROUND_FILL);
    laLayer_SetBufferCount(layer0, 1);

    laScreen_SetLayer(screen, 0, layer0);

    GradientWidget1 = laGradientWidget_New();
    laWidget_SetSize((laWidget*)GradientWidget1, 240, 320);
    laWidget_SetScheme((laWidget*)GradientWidget1, &BackGrowndGradient);
    laWidget_SetBackgroundType((laWidget*)GradientWidget1, LA_WIDGET_BACKGROUND_FILL);
    laWidget_SetBorderType((laWidget*)GradientWidget1, LA_WIDGET_BORDER_NONE);
    laGradientWidget_SetDirection((laGradientWidget*)GradientWidget1, LA_GRADIENT_DIRECTION_DOWN);
    laWidget_AddChild((laWidget*)layer0, (laWidget*)GradientWidget1);

    LabelWidget2 = laLabelWidget_New();
    laWidget_SetSize((laWidget*)LabelWidget2, 240, 34);
    laWidget_SetScheme((laWidget*)LabelWidget2, &WindowCaption);
    laWidget_SetBackgroundType((laWidget*)LabelWidget2, LA_WIDGET_BACKGROUND_NONE);
    laWidget_SetBorderType((laWidget*)LabelWidget2, LA_WIDGET_BORDER_NONE);
    laLabelWidget_SetText(LabelWidget2, laString_CreateFromID(string_MainWndCaption));
    laWidget_AddChild((laWidget*)layer0, (laWidget*)LabelWidget2);

    PanelWidget4 = laWidget_New();
    laWidget_SetPosition((laWidget*)PanelWidget4, 0, 31);
    laWidget_SetSize((laWidget*)PanelWidget4, 240, 4);
    laWidget_SetBackgroundType((laWidget*)PanelWidget4, LA_WIDGET_BACKGROUND_FILL);
    laWidget_SetBorderType((laWidget*)PanelWidget4, LA_WIDGET_BORDER_NONE);
    laWidget_AddChild((laWidget*)layer0, PanelWidget4);

    MainOKBtn = laButtonWidget_New();
    laWidget_SetPosition((laWidget*)MainOKBtn, 15, 272);
    laWidget_SetSize((laWidget*)MainOKBtn, 80, 33);
    laWidget_SetScheme((laWidget*)MainOKBtn, &ButtonsNormal);
    laWidget_SetBackgroundType((laWidget*)MainOKBtn, LA_WIDGET_BACKGROUND_FILL);
    laWidget_SetBorderType((laWidget*)MainOKBtn, LA_WIDGET_BORDER_BEVEL);
    laButtonWidget_SetText(MainOKBtn, laString_CreateFromID(string_ButtonOK));
    laWidget_AddChild((laWidget*)layer0, (laWidget*)MainOKBtn);

    MainCancelBtn = laButtonWidget_New();
    laWidget_SetPosition((laWidget*)MainCancelBtn, 146, 272);
    laWidget_SetSize((laWidget*)MainCancelBtn, 79, 33);
    laWidget_SetScheme((laWidget*)MainCancelBtn, &ButtonsNormal);
    laWidget_SetBackgroundType((laWidget*)MainCancelBtn, LA_WIDGET_BACKGROUND_FILL);
    laWidget_SetBorderType((laWidget*)MainCancelBtn, LA_WIDGET_BORDER_BEVEL);
    laButtonWidget_SetText(MainCancelBtn, laString_CreateFromID(string_ButtonCancel));
    laWidget_AddChild((laWidget*)layer0, (laWidget*)MainCancelBtn);

    LabelWidget = laLabelWidget_New();
    laWidget_SetPosition((laWidget*)LabelWidget, 35, 51);
    laWidget_SetSize((laWidget*)LabelWidget, 167, 55);
    laWidget_SetScheme((laWidget*)LabelWidget, &BigTextSchema);
    laWidget_SetBackgroundType((laWidget*)LabelWidget, LA_WIDGET_BACKGROUND_NONE);
    laWidget_SetBorderType((laWidget*)LabelWidget, LA_WIDGET_BORDER_NONE);
    laLabelWidget_SetText(LabelWidget, laString_CreateFromID(string_TemperatureLbl));
    laWidget_AddChild((laWidget*)layer0, (laWidget*)LabelWidget);

    ButtonWidget1 = laButtonWidget_New();
    laWidget_SetPosition((laWidget*)ButtonWidget1, 15, 106);
    laWidget_SetSize((laWidget*)ButtonWidget1, 54, 47);
    laWidget_SetScheme((laWidget*)ButtonWidget1, &ButtonsNormal);
    laWidget_SetBackgroundType((laWidget*)ButtonWidget1, LA_WIDGET_BACKGROUND_NONE);
    laWidget_SetBorderType((laWidget*)ButtonWidget1, LA_WIDGET_BORDER_BEVEL);
    laButtonWidget_SetPressedImage(ButtonWidget1, &App_devices_connector_icon32x32);
    laButtonWidget_SetReleasedImage(ButtonWidget1, &App_devices_connector_icon32x32);
    laButtonWidget_SetReleasedEventCallback(ButtonWidget1, &ButtonWidget1_ReleasedEvent);

    laWidget_AddChild((laWidget*)layer0, (laWidget*)ButtonWidget1);

    EEPromBtn = laButtonWidget_New();
    laWidget_SetPosition((laWidget*)EEPromBtn, 15, 160);
    laWidget_SetSize((laWidget*)EEPromBtn, 54, 47);
    laWidget_SetScheme((laWidget*)EEPromBtn, &ButtonsNormal);
    laWidget_SetBackgroundType((laWidget*)EEPromBtn, LA_WIDGET_BACKGROUND_NONE);
    laWidget_SetBorderType((laWidget*)EEPromBtn, LA_WIDGET_BORDER_BEVEL);
    laButtonWidget_SetPressedImage(EEPromBtn, &typewr1);
    laButtonWidget_SetReleasedImage(EEPromBtn, &typewr1);
    laButtonWidget_SetReleasedEventCallback(EEPromBtn, &EEPromBtn_ReleasedEvent);

    laWidget_AddChild((laWidget*)layer0, (laWidget*)EEPromBtn);

    ButtonWidget2 = laButtonWidget_New();
    laWidget_SetPosition((laWidget*)ButtonWidget2, 15, 215);
    laWidget_SetSize((laWidget*)ButtonWidget2, 54, 47);
    laWidget_SetScheme((laWidget*)ButtonWidget2, &ButtonsNormal);
    laWidget_SetBackgroundType((laWidget*)ButtonWidget2, LA_WIDGET_BACKGROUND_NONE);
    laWidget_SetBorderType((laWidget*)ButtonWidget2, LA_WIDGET_BORDER_BEVEL);
    laButtonWidget_SetPressedImage(ButtonWidget2, &tools4);
    laButtonWidget_SetReleasedImage(ButtonWidget2, &tools4);
    laWidget_AddChild((laWidget*)layer0, (laWidget*)ButtonWidget2);

    LabelWidget = laLabelWidget_New();
    laWidget_SetPosition((laWidget*)LabelWidget, 75, 116);
    laWidget_SetSize((laWidget*)LabelWidget, 154, 25);
    laWidget_SetScheme((laWidget*)LabelWidget, &BigTextSchema);
    laWidget_SetBackgroundType((laWidget*)LabelWidget, LA_WIDGET_BACKGROUND_NONE);
    laWidget_SetBorderType((laWidget*)LabelWidget, LA_WIDGET_BORDER_NONE);
    laLabelWidget_SetText(LabelWidget, laString_CreateFromID(string_TouchConfigWndStr));
    laLabelWidget_SetHAlignment(LabelWidget, LA_HALIGN_LEFT);
    laWidget_AddChild((laWidget*)layer0, (laWidget*)LabelWidget);

    LabelWidget4 = laLabelWidget_New();
    laWidget_SetPosition((laWidget*)LabelWidget4, 75, 171);
    laWidget_SetSize((laWidget*)LabelWidget4, 154, 25);
    laWidget_SetScheme((laWidget*)LabelWidget4, &BigTextSchema);
    laWidget_SetBackgroundType((laWidget*)LabelWidget4, LA_WIDGET_BACKGROUND_NONE);
    laWidget_SetBorderType((laWidget*)LabelWidget4, LA_WIDGET_BORDER_NONE);
    laLabelWidget_SetText(LabelWidget4, laString_CreateFromID(string_DemoScreenStr));
    laLabelWidget_SetHAlignment(LabelWidget4, LA_HALIGN_LEFT);
    laWidget_AddChild((laWidget*)layer0, (laWidget*)LabelWidget4);

    LabelWidget5 = laLabelWidget_New();
    laWidget_SetPosition((laWidget*)LabelWidget5, 75, 225);
    laWidget_SetSize((laWidget*)LabelWidget5, 154, 25);
    laWidget_SetScheme((laWidget*)LabelWidget5, &BigTextSchema);
    laWidget_SetBackgroundType((laWidget*)LabelWidget5, LA_WIDGET_BACKGROUND_NONE);
    laWidget_SetBorderType((laWidget*)LabelWidget5, LA_WIDGET_BORDER_NONE);
    laLabelWidget_SetText(LabelWidget5, laString_CreateFromID(string_ConfigBtnStr));
    laLabelWidget_SetHAlignment(LabelWidget5, LA_HALIGN_LEFT);
    laWidget_AddChild((laWidget*)layer0, (laWidget*)LabelWidget5);

}

static void ScreenCreate_TouchCalibrationWnd(laScreen* screen)
{
    laLayer* layer0;

    layer0 = laLayer_New();
    laWidget_SetPosition((laWidget*)layer0, 0, 0);
    laWidget_SetSize((laWidget*)layer0, 240, 320);
    laWidget_SetBackgroundType((laWidget*)layer0, LA_WIDGET_BACKGROUND_FILL);
    laLayer_SetBufferCount(layer0, 1);

    laScreen_SetLayer(screen, 0, layer0);

    GradientWidget = laGradientWidget_New();
    laWidget_SetSize((laWidget*)GradientWidget, 240, 320);
    laWidget_SetScheme((laWidget*)GradientWidget, &BackGrowndGradient);
    laWidget_SetBackgroundType((laWidget*)GradientWidget, LA_WIDGET_BACKGROUND_FILL);
    laWidget_SetBorderType((laWidget*)GradientWidget, LA_WIDGET_BORDER_NONE);
    laGradientWidget_SetDirection((laGradientWidget*)GradientWidget, LA_GRADIENT_DIRECTION_DOWN);
    laWidget_AddChild((laWidget*)layer0, (laWidget*)GradientWidget);

    TouchCalibrationWndCaption = laLabelWidget_New();
    laWidget_SetSize((laWidget*)TouchCalibrationWndCaption, 240, 34);
    laWidget_SetScheme((laWidget*)TouchCalibrationWndCaption, &WindowCaption);
    laWidget_SetBackgroundType((laWidget*)TouchCalibrationWndCaption, LA_WIDGET_BACKGROUND_NONE);
    laWidget_SetBorderType((laWidget*)TouchCalibrationWndCaption, LA_WIDGET_BORDER_NONE);
    laLabelWidget_SetText(TouchCalibrationWndCaption, laString_CreateFromID(string_TouchConfigWndStr));
    laWidget_AddChild((laWidget*)GradientWidget, (laWidget*)TouchCalibrationWndCaption);

    PanelWidget6 = laWidget_New();
    laWidget_SetPosition((laWidget*)PanelWidget6, 0, 31);
    laWidget_SetSize((laWidget*)PanelWidget6, 240, 4);
    laWidget_SetBackgroundType((laWidget*)PanelWidget6, LA_WIDGET_BACKGROUND_FILL);
    laWidget_SetBorderType((laWidget*)PanelWidget6, LA_WIDGET_BORDER_NONE);
    laWidget_AddChild((laWidget*)GradientWidget, PanelWidget6);

    ButtonWidget7 = laButtonWidget_New();
    laWidget_SetPosition((laWidget*)ButtonWidget7, 146, 272);
    laWidget_SetSize((laWidget*)ButtonWidget7, 79, 33);
    laWidget_SetScheme((laWidget*)ButtonWidget7, &ButtonsNormal);
    laWidget_SetBackgroundType((laWidget*)ButtonWidget7, LA_WIDGET_BACKGROUND_FILL);
    laWidget_SetBorderType((laWidget*)ButtonWidget7, LA_WIDGET_BORDER_BEVEL);
    laButtonWidget_SetText(ButtonWidget7, laString_CreateFromID(string_RetryStr));
    laButtonWidget_SetReleasedEventCallback(ButtonWidget7, &ButtonWidget7_ReleasedEvent);

    laWidget_AddChild((laWidget*)GradientWidget, (laWidget*)ButtonWidget7);

    ButtonWidget8 = laButtonWidget_New();
    laWidget_SetPosition((laWidget*)ButtonWidget8, 15, 272);
    laWidget_SetSize((laWidget*)ButtonWidget8, 80, 33);
    laWidget_SetScheme((laWidget*)ButtonWidget8, &ButtonsNormal);
    laWidget_SetBackgroundType((laWidget*)ButtonWidget8, LA_WIDGET_BACKGROUND_FILL);
    laWidget_SetBorderType((laWidget*)ButtonWidget8, LA_WIDGET_BORDER_BEVEL);
    laButtonWidget_SetText(ButtonWidget8, laString_CreateFromID(string_ButtonOK));
    laWidget_AddChild((laWidget*)GradientWidget, (laWidget*)ButtonWidget8);

    CirclePoint = laCircleWidget_New();
    laWidget_SetPosition((laWidget*)CirclePoint, 30, 42);
    laWidget_SetSize((laWidget*)CirclePoint, 23, 24);
    laWidget_SetScheme((laWidget*)CirclePoint, &Primitives);
    laWidget_SetBackgroundType((laWidget*)CirclePoint, LA_WIDGET_BACKGROUND_NONE);
    laWidget_SetBorderType((laWidget*)CirclePoint, LA_WIDGET_BORDER_NONE);
    laCircleWidget_SetOrigin(CirclePoint, 11, 11);
    laCircleWidget_SetRadius(CirclePoint, 11);
    laWidget_AddChild((laWidget*)layer0, (laWidget*)CirclePoint);

    ImageWidget6 = laImageWidget_New();
    laWidget_SetPosition((laWidget*)ImageWidget6, 4, 4);
    laWidget_SetSize((laWidget*)ImageWidget6, 16, 14);
    laWidget_SetBackgroundType((laWidget*)ImageWidget6, LA_WIDGET_BACKGROUND_NONE);
    laWidget_SetBorderType((laWidget*)ImageWidget6, LA_WIDGET_BORDER_NONE);
    laImageWidget_SetImage(ImageWidget6, &FilledRedCircleJpg);
    laWidget_AddChild((laWidget*)CirclePoint, (laWidget*)ImageWidget6);

    TouchPointLbl = laLabelWidget_New();
    laWidget_SetPosition((laWidget*)TouchPointLbl, 0, 70);
    laWidget_SetSize((laWidget*)TouchPointLbl, 91, 25);
    laWidget_SetScheme((laWidget*)TouchPointLbl, &BigTextSchema);
    laWidget_SetBackgroundType((laWidget*)TouchPointLbl, LA_WIDGET_BACKGROUND_NONE);
    laWidget_SetBorderType((laWidget*)TouchPointLbl, LA_WIDGET_BORDER_NONE);
    laLabelWidget_SetText(TouchPointLbl, laString_CreateFromID(string_TouchPointStr));
    laWidget_AddChild((laWidget*)layer0, (laWidget*)TouchPointLbl);

    LabelWidget1 = laLabelWidget_New();
    laWidget_SetPosition((laWidget*)LabelWidget1, 41, 130);
    laWidget_SetSize((laWidget*)LabelWidget1, 170, 29);
    laWidget_SetScheme((laWidget*)LabelWidget1, &BigTextSchema);
    laWidget_SetBackgroundType((laWidget*)LabelWidget1, LA_WIDGET_BACKGROUND_NONE);
    laWidget_SetBorderType((laWidget*)LabelWidget1, LA_WIDGET_BORDER_NONE);
    laLabelWidget_SetText(LabelWidget1, laString_CreateFromID(string_TouchInstruction1Str));
    laWidget_AddChild((laWidget*)layer0, (laWidget*)LabelWidget1);

    LabelWidget3 = laLabelWidget_New();
    laWidget_SetPosition((laWidget*)LabelWidget3, 40, 150);
    laWidget_SetSize((laWidget*)LabelWidget3, 170, 29);
    laWidget_SetScheme((laWidget*)LabelWidget3, &BigTextSchema);
    laWidget_SetBackgroundType((laWidget*)LabelWidget3, LA_WIDGET_BACKGROUND_NONE);
    laWidget_SetBorderType((laWidget*)LabelWidget3, LA_WIDGET_BORDER_NONE);
    laLabelWidget_SetText(LabelWidget3, laString_CreateFromID(string_TouchInstruction2Str));
    laWidget_AddChild((laWidget*)layer0, (laWidget*)LabelWidget3);

}

static void ScreenCreate_DemoWnd(laScreen* screen)
{
    laLayer* layer0;

    layer0 = laLayer_New();
    laWidget_SetPosition((laWidget*)layer0, 0, 0);
    laWidget_SetSize((laWidget*)layer0, 240, 320);
    laWidget_SetBackgroundType((laWidget*)layer0, LA_WIDGET_BACKGROUND_FILL);
    laLayer_SetBufferCount(layer0, 1);

    laScreen_SetLayer(screen, 0, layer0);

    GradientWidget2 = laGradientWidget_New();
    laWidget_SetSize((laWidget*)GradientWidget2, 240, 320);
    laWidget_SetScheme((laWidget*)GradientWidget2, &BackGrowndGradient);
    laWidget_SetBackgroundType((laWidget*)GradientWidget2, LA_WIDGET_BACKGROUND_FILL);
    laWidget_SetBorderType((laWidget*)GradientWidget2, LA_WIDGET_BORDER_NONE);
    laGradientWidget_SetDirection((laGradientWidget*)GradientWidget2, LA_GRADIENT_DIRECTION_DOWN);
    laWidget_AddChild((laWidget*)layer0, (laWidget*)GradientWidget2);

    LabelWidget6 = laLabelWidget_New();
    laWidget_SetSize((laWidget*)LabelWidget6, 240, 34);
    laWidget_SetScheme((laWidget*)LabelWidget6, &WindowCaption);
    laWidget_SetBackgroundType((laWidget*)LabelWidget6, LA_WIDGET_BACKGROUND_NONE);
    laWidget_SetBorderType((laWidget*)LabelWidget6, LA_WIDGET_BORDER_NONE);
    laLabelWidget_SetText(LabelWidget6, laString_CreateFromID(string_DemoWndCaption));
    laWidget_AddChild((laWidget*)GradientWidget2, (laWidget*)LabelWidget6);

    PanelWidget7 = laWidget_New();
    laWidget_SetPosition((laWidget*)PanelWidget7, 0, 31);
    laWidget_SetSize((laWidget*)PanelWidget7, 240, 4);
    laWidget_SetBackgroundType((laWidget*)PanelWidget7, LA_WIDGET_BACKGROUND_FILL);
    laWidget_SetBorderType((laWidget*)PanelWidget7, LA_WIDGET_BORDER_NONE);
    laWidget_AddChild((laWidget*)GradientWidget2, PanelWidget7);

    ButtonWidget9 = laButtonWidget_New();
    laWidget_SetPosition((laWidget*)ButtonWidget9, 146, 272);
    laWidget_SetSize((laWidget*)ButtonWidget9, 79, 33);
    laWidget_SetScheme((laWidget*)ButtonWidget9, &ButtonsNormal);
    laWidget_SetBackgroundType((laWidget*)ButtonWidget9, LA_WIDGET_BACKGROUND_FILL);
    laWidget_SetBorderType((laWidget*)ButtonWidget9, LA_WIDGET_BORDER_BEVEL);
    laButtonWidget_SetText(ButtonWidget9, laString_CreateFromID(string_ButtonCancel));
    laButtonWidget_SetReleasedEventCallback(ButtonWidget9, &ButtonWidget9_ReleasedEvent);

    laWidget_AddChild((laWidget*)GradientWidget2, (laWidget*)ButtonWidget9);

    ButtonWidget10 = laButtonWidget_New();
    laWidget_SetPosition((laWidget*)ButtonWidget10, 15, 272);
    laWidget_SetSize((laWidget*)ButtonWidget10, 80, 33);
    laWidget_SetScheme((laWidget*)ButtonWidget10, &ButtonsNormal);
    laWidget_SetBackgroundType((laWidget*)ButtonWidget10, LA_WIDGET_BACKGROUND_FILL);
    laWidget_SetBorderType((laWidget*)ButtonWidget10, LA_WIDGET_BORDER_BEVEL);
    laButtonWidget_SetText(ButtonWidget10, laString_CreateFromID(string_ButtonOK));
    laWidget_AddChild((laWidget*)GradientWidget2, (laWidget*)ButtonWidget10);

    DrawSurfaceWidget13 = laDrawSurfaceWidget_New();
    laWidget_SetPosition((laWidget*)DrawSurfaceWidget13, 60, 100);
    laWidget_SetSize((laWidget*)DrawSurfaceWidget13, 121, 118);
    laWidget_SetBackgroundType((laWidget*)DrawSurfaceWidget13, LA_WIDGET_BACKGROUND_FILL);
    laWidget_SetBorderType((laWidget*)DrawSurfaceWidget13, LA_WIDGET_BORDER_NONE);
    laDrawSurfaceWidget_SetDrawCallback(DrawSurfaceWidget13, &DrawSurfaceWidget13_DrawNotificationEvent);

    laWidget_AddChild((laWidget*)GradientWidget2, (laWidget*)DrawSurfaceWidget13);

    CircleWidget14 = laCircleWidget_New();
    laWidget_SetPosition((laWidget*)CircleWidget14, 6, 13);
    laWidget_SetSize((laWidget*)CircleWidget14, 101, 101);
    laWidget_SetBackgroundType((laWidget*)CircleWidget14, LA_WIDGET_BACKGROUND_NONE);
    laWidget_SetBorderType((laWidget*)CircleWidget14, LA_WIDGET_BORDER_NONE);
    laWidget_AddChild((laWidget*)DrawSurfaceWidget13, (laWidget*)CircleWidget14);

    LineWidget16 = laLineWidget_New();
    laWidget_SetPosition((laWidget*)LineWidget16, 6, 13);
    laWidget_SetSize((laWidget*)LineWidget16, 100, 100);
    laWidget_SetBackgroundType((laWidget*)LineWidget16, LA_WIDGET_BACKGROUND_NONE);
    laWidget_SetBorderType((laWidget*)LineWidget16, LA_WIDGET_BORDER_NONE);
    laLineWidget_SetStartPoint(LineWidget16, 0, 100);
    laLineWidget_SetEndPoint(LineWidget16, 100, 0);
    laWidget_AddChild((laWidget*)DrawSurfaceWidget13, (laWidget*)LineWidget16);

    LineWidget15 = laLineWidget_New();
    laWidget_SetPosition((laWidget*)LineWidget15, 17, 20);
    laWidget_SetSize((laWidget*)LineWidget15, 100, 100);
    laWidget_SetBackgroundType((laWidget*)LineWidget15, LA_WIDGET_BACKGROUND_NONE);
    laWidget_SetBorderType((laWidget*)LineWidget15, LA_WIDGET_BORDER_NONE);
    laLineWidget_SetStartPoint(LineWidget15, 100, 100);
    laLineWidget_SetEndPoint(LineWidget15, 0, 0);
    laWidget_AddChild((laWidget*)DrawSurfaceWidget13, (laWidget*)LineWidget15);

    TextFieldWidget11 = laTextFieldWidget_New();
    laWidget_SetPosition((laWidget*)TextFieldWidget11, 76, 46);
    laWidget_SetSize((laWidget*)TextFieldWidget11, 100, 25);
    laWidget_SetBackgroundType((laWidget*)TextFieldWidget11, LA_WIDGET_BACKGROUND_FILL);
    laWidget_SetBorderType((laWidget*)TextFieldWidget11, LA_WIDGET_BORDER_BEVEL);
    laTextFieldWidget_SetCursorEnabled(TextFieldWidget11, LA_TRUE);
    laWidget_AddChild((laWidget*)layer0, (laWidget*)TextFieldWidget11);

}



