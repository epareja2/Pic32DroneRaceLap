/*******************************************************************************
  MPLAB Harmony Graphics Composer Generated Definitions Header

  File Name:
    libaria_macros.h

  Summary:
    Build-time generated definitions header based on output by the MPLAB Harmony
    Graphics Composer.

  Description:
    Build-time generated definitions header based on output by the MPLAB Harmony
    Graphics Composer.

    Created with MPLAB Harmony Version 2.04
*******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*******************************************************************************/
// DOM-IGNORE-END

#ifndef _LIBARIA_INIT_H
#define _LIBARIA_INIT_H

#ifndef NATIVE
#include "system_config.h"
#include "system_definitions.h"
#endif

#include "gfx/libaria/libaria.h"
#include "gfx/libaria/libaria_events.h"

#include "gfx/gfx_assets.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

extern "C" {

#endif
// DOM-IGNORE-END 

#define LIBARIA_SCREEN_COUNT   3

// reference IDs for generated libaria screens
// screen "DemoWnd"
#define DemoWnd_ID    2

// screen "MainWnd"
#define MainWnd_ID    0

// screen "TouchCalibrationWnd"
#define TouchCalibrationWnd_ID    1



extern laScheme defaultScheme;
extern laScheme BackGrowndGradient;
extern laScheme BigTextSchema;
extern laScheme Primitives;
extern laScheme ButtonsNormal;
extern laScheme WindowCaption;
extern laGradientWidget* GradientWidget1;
extern laLabelWidget* LabelWidget2;
extern laWidget* PanelWidget4;
extern laButtonWidget* MainOKBtn;
extern laButtonWidget* MainCancelBtn;
extern laLabelWidget* LabelWidget;
extern laButtonWidget* ButtonWidget1;
extern laButtonWidget* EEPromBtn;
extern laButtonWidget* ButtonWidget2;
extern laLabelWidget* LabelWidget;
extern laLabelWidget* LabelWidget4;
extern laLabelWidget* LabelWidget5;
extern laGradientWidget* GradientWidget;
extern laLabelWidget* TouchCalibrationWndCaption;
extern laWidget* PanelWidget6;
extern laButtonWidget* ButtonWidget7;
extern laButtonWidget* ButtonWidget8;
extern laCircleWidget* CirclePoint;
extern laImageWidget* ImageWidget6;
extern laLabelWidget* TouchPointLbl;
extern laLabelWidget* LabelWidget1;
extern laLabelWidget* LabelWidget3;
extern laGradientWidget* GradientWidget2;
extern laLabelWidget* LabelWidget6;
extern laWidget* PanelWidget7;
extern laButtonWidget* ButtonWidget9;
extern laButtonWidget* ButtonWidget10;
extern laDrawSurfaceWidget* DrawSurfaceWidget13;
extern laCircleWidget* CircleWidget14;
extern laLineWidget* LineWidget16;
extern laLineWidget* LineWidget15;
extern laTextFieldWidget* TextFieldWidget11;


int32_t libaria_initialize(void);

//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif // _LIBARIA_INIT_H
/*******************************************************************************
 End of File
*/
