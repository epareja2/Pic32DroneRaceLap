#include "gfx/utils/inc/gfxu_palette.h"

GFX_Color GFXU_PaletteGetColor(GFXU_PaletteAsset* pal,
                               uint32_t idx,
                               GFXU_MemoryIntf* read_cb,
                               GFXU_ExternalAssetReader** reader)
{
    return 0;
}